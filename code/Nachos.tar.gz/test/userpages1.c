#include "syscall.h"
#define THIS "aaa"
#define THAT "bbb"
const int N = 10; // Choose it large enough!
void puts(char *s)
{
char *p; for (p = s; *p != '\0'; p++) PutChar(*p);
}
void f(void *s)
{
int i; for (i = 0; i < N; i++) puts((char *)s);
UserThreadExit();
}
void print(char *s)
{
	int i=0;
	for (i = 0; i < N; i++) 
		PutString(s);
	PutChar('\n');
}
int main()
{
void * p = f;
UserThreadCreate(p,THIS);
//UserThreadJoin(1);
//f((void *)THAT);
print(THAT);
Halt();
}