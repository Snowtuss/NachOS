#include "syscall.h"

int main(){
	PutInt(GetInt());
	PutChar('\n');
	//Halt();
	return 0;
}