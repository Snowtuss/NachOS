#include "syscall.h"

int main(){
	int returnFork0,returnFork1;
	returnFork0 = ForkExec("../build/userpages0");
	returnFork1 = ForkExec("../build/userpages1");
	PutInt(returnFork0);
	PutChar('\n');
	PutInt(returnFork1);
	Halt();
}

